package Tree;

public class BinaryTree {

	Node root;
	public void add(int data)
	{
		Node nodeToAdd=new Node(data);
		
		if(root==null)
			root=nodeToAdd;
		
		//if data is less than the node then treverse left else traverse right
		Node traversingNode= root;
	
	}
	private void traverseAndAddNode(Node node, Node nodeToAdd)
	{
		
		if(nodeToAdd.data<root.data)
		{
			if(node.leftChild==null)
			{
				node.leftChild=nodeToAdd;
			}
			else 
			{
			traverseAndAddNode(node.leftChild, nodeToAdd);
			}
		}
		else if(nodeToAdd.data>root.data)
		{
			if(node.rightChild==null)
			{
				node.rightChild=nodeToAdd;
			}
			else
			{
			traverseAndAddNode(node.rightChild, nodeToAdd);
			}
		}
	}
	public void traverse()
	{//pre order treversal-in order- post order
		if(root!=null)
		{
			Node nodeToTraverse=root;
			if(nodeToTraverse.leftChild!=null)
			{
				inOrdertraverse(nodeToTraverse.leftChild);
			}
		}
	}
	private void inOrdertraverse(Node node)
	{//pre order treversal-in order- post order
		
			if(node.leftChild!=null)
			{
				inOrdertraverse(node.leftChild);
			}
		   System.out.println(node.data);
		   
		   if(node.rightChild!=null)
		   {
			   inOrdertraverse(node.rightChild);
		   }
		
	}
}
