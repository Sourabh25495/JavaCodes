import java.util.*;
public class Fibonacci {

	public static void main(String[] args) {
		int a=0,b=1,i=2,c;
		int ele;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the number of elements in the series ");
		ele=sc.nextInt();
		c=a+b;
		System.out.print(a+" "+b+" ");
		while(i<ele)
		{
			a=b;
			b=c;
			c=a+b;
			System.out.print(c+" ");
			
			i++;
			
		}

	}

}
