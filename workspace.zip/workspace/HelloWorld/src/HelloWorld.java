
public class HelloWorld {
	public static void main(String[] args){
	
	System.out.println("Hello");
	System.out.println("hi");
int a=4;
int b=5;
int x=a+b;
System.out.print(x);
}
}