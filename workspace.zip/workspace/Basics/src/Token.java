import java.util.*;
public class Token {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String s=" ";
		s=sc.nextLine();
		StringTokenizer stringToken=new StringTokenizer(s," ![,?.\\_'@+]");
		System.out.println(stringToken.countTokens());
	    while(stringToken.hasMoreTokens())
	    {
	    	System.out.println(stringToken.nextToken());
	    }
		

	}

}
