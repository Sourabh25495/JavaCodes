import java.util.*;
public class Mapping {

	public static void main(String[] args) {
		Scanner in= new Scanner(System.in);
		HashMap<String, Integer> map=new HashMap<>();
		int n=in.nextInt();
		in.nextLine();
		
		for(int i=0;i<n;i++)
		{
			String s=in.next();
			int a=in.nextInt();
			map.put(s, a);
			in.nextLine();
		}
		
		while(in.hasNext()){
			String s= in.nextLine();
					if(map.containsKey(s)){
						System.out.println(s+"="+map.get(s));
						
					}else{
						System.out.println("Not Found");
					}
		}
				

	}

}
