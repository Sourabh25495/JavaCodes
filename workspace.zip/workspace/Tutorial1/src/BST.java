
public class BST {
	Node root;

	public BST(){
		root =null;
	}
	public static void main(String[] args) {
		BST b1=new BST();
		
	}

}
