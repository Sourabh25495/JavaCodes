import java.util.Scanner;
public class MatrixMultiPlication {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int m,n,p,q,sum=0,i,j,k;
		System.out.println("Number of rows and columns");
		m=sc.nextInt();
		n=sc.nextInt();
		int first[][]=new int[m][n];
		System.out.println("Enter the first matrix");
		for(i=0;i<m;i++)
		   for(j=0;j<n;j++)
			   first[i][j]=sc.nextInt();
		
		System.out.println("Enter rows and columns of matrix 2");
		p=sc.nextInt();
		q=sc.nextInt();
		if(n!=p)
			System.out.println("Action cant be preformed");
		else
		{
			int second[][]=new int[p][q];
			System.out.println("enter second matrix");
			for(i=0;i<p;i++)
				   for(j=0;j<q;j++)
					   second[i][j]=sc.nextInt();
			
			int multiply[][]=new int[m][q];
			
			for(i=0;i<m;i++)
			{
				for(j=0;j<q;j++)
				{
					for(k=0;k<p;k++)
					{
						sum=sum+first[i][k]*second[k][j];
					}
					multiply[i][j]=sum;
					sum=0;
				}
			}
			System.out.println("Display the output");
			for(i=0;i<m;i++)
			{
				for(j=0;j<q;j++)
					System.out.print(multiply[i][j]+"\t");
				System.out.print("\n");
			}
			
		}
		
	}

}
