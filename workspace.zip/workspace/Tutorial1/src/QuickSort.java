import java.util.Scanner;

public class QuickSort {

	private static void QucikSortImplement(int arr[], int left, int right)
	{
		int index = partition(arr, left, right);
		
		if(left<index-1)
			QucikSortImplement(arr, left, index-1);
		if(left<index-1)
			QucikSortImplement(arr, index, right);
	}
	private static int partition(int[] arr, int left, int right){
		int pivot= arr[(left+right)/2];
		while(left<=right){
			while(arr[left]<pivot) left++;
			while(arr[right]>pivot) right--;
			
			if(left<=right){
				int temp=arr[left];
				arr[left]=arr[right];
				arr[right]=temp;
				
				left++;
				right--;
			}
		}
		return left;
	}
	public static void main(String[] args){
		int l;
		System.out.println("enter the length");
		Scanner in=new Scanner(System.in);
		l= in.nextInt();
		
		
		int[] a= new int[l];
		int i;
		for(i=0;i<l;i++)
		{
			System.out.println("enter element"+(i+1));
			a[i]=in.nextInt();
		}
		in.close();
		QucikSortImplement(a,0,a.length-1);
		for(i=0;i<a.length;i++)
			System.out.println(a[i]+" ");
	}
}
