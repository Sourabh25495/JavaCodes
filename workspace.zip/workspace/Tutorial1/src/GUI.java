import javax.swing.JOptionPane;

public class GUI {
public static void main(String args[]){
	Double n= Double.parseDouble(JOptionPane.showInputDialog("Is aiman Mad?"));
	if((n-1.5)<.00001)
	{
		JOptionPane.showMessageDialog(null, "you are correct");
		
	}else {JOptionPane.showMessageDialog(null,  "you are wrong");}
}
}
