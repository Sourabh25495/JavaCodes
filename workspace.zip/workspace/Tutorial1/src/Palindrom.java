import java.util.Scanner;

public class Palindrom {
		

			public static void main(String[] args) {
				String l;
				System.out.println("enter the string");
				Scanner in=new Scanner(System.in);
				l= in.nextLine();
			
				
				
				char[] a;
			    a=l.toCharArray();
			    for(int i=0;i<a.length;i++){
			    //	System.out.println("Source Position "+i+" is now "+a[i]);
			    }
			    
			 System.out.println("length of the array is "+a.length);
			 char[] b= new char[a.length];
			 
			 for(int i=0;i<a.length;i++){
				 b[i]=a[a.length-1-i];
				// System.out.println(b[i]);
			 } 
			int i;
			boolean equal=true;
			for(i=0;i<a.length;i++){
				if(a[i]==b[i])
					equal=true;
				else
					equal=false;
             }
			System.out.println("Is this String a Palindrom? "+ equal);
	}
	}
