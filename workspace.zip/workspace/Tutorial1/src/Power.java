import java.util.Scanner;

public class Power {
	
	public static void raiseTO(int x, int y)
	{
		//int count=0;
		float m = 1;
		
		while(true)
		{
		    //m=x*x;
			//count++;
			if(y==0)
			{System.out.println("ans= "+1);}
			else if(y<0)
			{
				y=y*-1;
				for(int i=0;i<y;i++)
				{
					m*=x;
				}

				System.out.println("ans= "+1/m );
				break;
			}
			
			else if(y!=0)
			{
				for(int i=0;i<y;i++)
				{
					m*=x;
				}
				System.out.println("The ans is "+ m);
				break;
			}
			else if(x==0){
				System.out.println("The ans is "+ 0);
				break;
			}
			
			
			
		}
		
		
		
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the base");
		int a=sc.nextInt();
		System.out.println("enter raise to power");
		int b= sc.nextInt();
		raiseTO(a,b);

	}

}
