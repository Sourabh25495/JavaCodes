import java.util.*;
public class Bs {

	public static void main(String[] args) {
		int l;
		System.out.println("enter the length");
		Scanner in=new Scanner(System.in);
		l= in.nextInt();
		
		
		
		int[] a= new int[l];
		int i, temp;
		for(i=0;i<l;i++)
		{
			System.out.println("enter element"+(i+1));
			a[i]=in.nextInt();
		}
		in.close();
		
		for(i=0;i<a.length-1;i++){
			for(int j=0;j<a.length-1;j++){
				if(a[j]>a[j+1])
				{ 
					temp= a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}

	}

}
