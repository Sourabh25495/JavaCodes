
public class Objects {

	int twater=0;
	public Objects(){
		
	}
	public Objects(int waterAmount){
		twater=waterAmount;
	}
	
	public void addWater(int amount){
		twater=twater+amount;
	}
 public void drinkWater(int amount){
	 twater=twater-amount;
 }
 public int getWater(){
	 return twater;
	
 }
}
