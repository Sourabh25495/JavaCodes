import java.applet.Applet;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Color;
import java.awt.Dimension;

public class Mouseclicks extends Applet implements MouseListener {
	private Graphics globalGraphics = null;
	public void init()
	{
		this.addMouseListener(this);
	}
	public void paint(Graphics g)
	{
		this.setSize(new Dimension(800,600));
		
			globalGraphics=g.create();
	}
	public void drawDot(int x, int y, int width,int height)
	{
		int r= (int)(Math.random()* 255);
		int g= (int)(Math.random()* 255);
		int b= (int)(Math.random()* 255);
		Color randomColor= new Color(r,g,b);
		globalGraphics.setColor(randomColor);
		globalGraphics.fillRect(x, y, width, height);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		//System.out.println("Click");
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		System.out.println("mouse Entered");
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		System.out.println("Mouse exit");
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		System.out.println("Pressed");
		boolean iscontrol= e.isControlDown();
		int mouseX= e.getX();
		int mouseY=e.getY();
		if(iscontrol)
			drawDot(mouseX, mouseY, 20, 20);
		else
			drawDot(mouseX, mouseY, 10, 10);
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		System.out.println("mouse released");
		
	}
	

}
