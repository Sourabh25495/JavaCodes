import java.util.*;
public class Pattern1 {

	public static void main(String[] args) {
		int i,j,row;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no. of rows");
		row=sc.nextInt();
		
		
		 for ( i = row; i >= 1; i--) 
	        {
	            //Printing i spaces at the beginning of each row
	             
	            for (j = 1; j < i; j++) 
	            {
	                System.out.print(" ");
	            }
	             
	            //Printing i to rows value at the end of each row
	             
	            for (j = 1; j <=row; j++)
	            {
	                System.out.print(j+" ");
	            }
	             
	            System.out.println();
	        }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		
		 for ( i = 1; i <= row; i++) 
	        {
	            //Printing i spaces at the beginning of each row
	             
	            for (j = 1; j < i; j++) 
	            {
	                System.out.print(" ");
	            }
	             
	            //Printing i to rows value at the end of each row
	             
	            for ( j = i; j <= row; j++) 
	            { 
	                System.out.print(j+" "); 
	            } 
	             
	            System.out.println(); 
	        } 
		
		for(i=1;i<=row;i++){
			for(j=1;j<=i;j++){
				System.out.print(j);
			}
			System.out.print("\n");
		}
		
		for(i=row-1;i>0;i--){
			for(j=1;j<=i;j++){
				System.out.print(j);
			}
			System.out.print("\n");
		}
		
		*/

	}

}
