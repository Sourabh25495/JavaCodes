import java.util.*;
public class Array123 {

	public static void main(String[] args) {
		int l;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the length");
		l=input.nextInt();
		
		int[] n= new int[l];
				
				for (int i=0;i<l; i++)
				{
					System.out.println("enter the elements"+(i+1));
					n[i]=input.nextInt();
				}
			//	input.close();
			//	System.out.println("names are");
				
			///	for (int i=0;i<l; i++)
				///{
				///	System.out.println(n[i]);
				
			///	}
				int temp;
				
				for(int i=0;i<n.length-1;i++)
				{
					for(int j=i+1;j<n.length-1;j++)
					{
						if(n[j]>n[j+1]){
							temp=n[i];
							n[i]=n[j+1];
							n[j+1]=temp;
							
						}
					}
				
				for(i=0;i<n.length;i++){
					System.out.println(n[i]+",");
				}
				//System.out.println();
				}
				
				
	}

}
