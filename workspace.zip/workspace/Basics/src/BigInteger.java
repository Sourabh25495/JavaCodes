import java.io.*;
import java.util.*;
import java.math.*;

public class BigInteger {
    static BigDecimal add(BigDecimal a,BigDecimal b){return a.add(b);}
                static BigDecimal multiply(BigDecimal a,BigDecimal b){return a.multiply(b);          }
    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner scan=new Scanner(System.in);
        String str1=scan.next();
        String str2=scan.next();
        System.out.println(add(new BigDecimal(str1),new BigDecimal(str2)));
        System.out.println(multiply(new BigDecimal(str1),new BigDecimal(str2)));
    }
}