package javadb_001;
import java.awt.color.*;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Work extends JPanel {
	
	public void paint(Graphics g){
		int i,j;
		g.fillRect(0, 0, 400, 400);
		for( i=0; i<=400;i+=100){
			for(j=0;j<=400;j+=100){
				g.clearRect(i, j, 50, 50);
			}
			
	}
	
	for(i=50;i<=400;i+=100){
		for(j=50; j<=400; j+=100){
			g.clearRect(i,j, 50, 50);
		}
	}
}
	
	
	public static void main(String args[])
	{
		JFrame frame=new JFrame();
		frame.setSize(422,455);
		frame.getContentPane().add(new Work());
		//frame.setLocationRelativeTo(null);
		frame.setBackground(Color.LIGHT_GRAY);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}

}
