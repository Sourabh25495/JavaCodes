package Tree;

public class Node {
	int data;
	Node leftChild;
	Node rightChild;
	
	public Node()
	{
		
	}
	public Node(int data)
	{
		this.data=data;
	}
	

}
