import java.io.BufferedReader;
import java.util.*;
import java.io.FileReader;
import java.io.IOException;

import java.util.*;
public class dataExtract {

	public static void main(String[] args) throws IOException {
		
		
		BufferedReader in = new BufferedReader(new FileReader("C:/Users/soura/Desktop/FamilyTree.txt"));
        String str;
        List<String> list = new ArrayList<String>();
        while((str = in.readLine()) != null){
            list.add(str);
        }
        final String[] stringArr = list.toArray(new String[0]);
  /*      
	for(int i=0;i<stringArr.length;i++){
		System.out.println(stringArr[i]);
		
	}
	*/
	Scanner scan = new Scanner(System.in);
	String[] words = new String[1000];
	for(int i = 0; i < stringArr.length ; i++)
	{
		String s = stringArr[i];
		for(int j = 0; j < stringArr[i].toString().length(); j++)
		{
			words = s.split(" ");
			System.out.println(words[i]);
		}
	}
	
	for(int i = 0; i < words.length; i++)
	{
		System.out.println(words[i]);
	}
}
}
