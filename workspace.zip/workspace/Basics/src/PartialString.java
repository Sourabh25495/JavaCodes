import java.util.*;

public class PartialString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String a=" ";
		String b=" ";
		//System.out.println("Enter String a");
		a=sc.nextLine();
		char[] CharArray= a.toCharArray();
		//System.out.println("Enter the Start and end points");
		int x=sc.nextInt();
		int y=sc.nextInt();
		
		for(int i=x;i<y;i++)
		{
			System.out.print(CharArray[i]);
		}

	}

}
