import java.util.*;
public class SubArr {

	public static void main(String[] args) {
	Scanner sc=new Scanner (System.in);
	int a=sc.nextInt();
	int c=0;
	int arr[]=new int[a];
	for(int i=0;i<a;i++)
	{
		arr[i]=sc.nextInt();
	}/*
	for(int i=0;i<a;i++)
	
		System.out.println(arr[i]);
*/
    for(int i=0;i<a;i++)
    {
    	int sum=arr[i];
    	if(sum<0)
    		c++;
    	for(int j=i+1;j<a;j++)
    	{
    		sum+=arr[j];
    		if(sum<0)
    			c++;
    	}
    }
    System.out.println(c);
	}

}
