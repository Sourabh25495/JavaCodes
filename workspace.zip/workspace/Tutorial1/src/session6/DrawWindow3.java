package session6;
import javax.swing.JFrame;
public class DrawWindow3 {
	
	DrawWindow3(){
		JFrame f= new JFrame("test");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(800,400);
		f.setVisible(true);	
	}
	
	
	
	
	
	public static void main(String[] args) {
	new DrawWindow3();
	new DrawWindow3();
	new DrawWindow3();
	
	}

}
