package cpe810j2016;

public class Fraction {

}
