import java.io.BufferedReader;
import java.io.FileReader;
public class FilesinJava {
public static void main(String[] args) throws Exception{
	FileReader file= new FileReader("C:/Users/soura/OneDrive/Documents/Java3.txt");
	BufferedReader reader = new BufferedReader(file);
	
	String text="";
	String line= reader.readLine();
	while(line!=null){
		text+=line;
				line=reader.readLine();
	}
	System.out.println(text);
}
}
