import java.util.Scanner;

public class SelectionSort {

	public static void main(String[] args) {
		int l;
		System.out.println("enter the length");
		Scanner in=new Scanner(System.in);
		l= in.nextInt();
	
		
		
		int[] a= new int[l];
		int i, temp;
		for(i=0;i<l;i++)
		{
			System.out.println("enter element"+(i+1));
			a[i]=in.nextInt();
		}
		in.close();
		
		int min; 
		int temp1;
		for(int j=0;j<a.length-1;j++)
		{
			min=j;
			for(int x=j+1;x<a.length;x++)
			{
				if(a[x]<a[min]){
					min=x;
				}
			}
			temp1=a[min];
			a[min]=a[j];
			a[j]=temp1;	
			
		}
		System.out.println("after sort");
		for(i=0;i<=a.length-1;i++)
			System.out.println(a[i]);

	}

}
