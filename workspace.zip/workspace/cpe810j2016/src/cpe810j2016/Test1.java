package cpe810j2016;

public class Test1 {
	public static void main(String args[])
	{ 
		System.out.println("hi");
		int a=2;
		System.out.println(a*3);
	
	
	int prod = 1 ;
	for (int i=1; i<10;i++)
		prod*=i;
	System.out.println(prod);

}}
