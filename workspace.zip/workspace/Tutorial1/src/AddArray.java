import java.util.Scanner;

public class AddArray {

	public static void main(String[] args) {
		 {
			
			int l;
			System.out.println("enter the length");
			Scanner in=new Scanner(System.in);
			l= in.nextInt();
			
			
			
			int[] a= new int[l];
			
			for(int i=0;i<l;i++)
			{
				System.out.println("enter element"+(i+1));
				a[i]=in.nextInt();
			}
			in.close();
			int sum=0;
			for(int i=0;i<a.length;i++){
				 sum+=a[i];
			}
			System.out.println("The sum of array is " + sum);
		

	}
	}
}

