import java.util.Scanner;
import javax.print.DocFlavor.INPUT_STREAM;
public class digitTester {
static Scanner input = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("welcome to digital extractor!! Enter your 5 digits");
		String in= input.nextLine();
		System.out.println("Mathematically");
		digitExtract de= new digitExtract(Integer.parseInt(in));
		de.returnInvertedOrderByMath();
		System.out.println("using string");
		digitExtract deconcpt= new digitExtract(in);
		deconcpt.returnInvertedOrderByString();
				

	}

}
