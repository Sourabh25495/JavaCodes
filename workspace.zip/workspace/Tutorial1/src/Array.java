import java.util.*;
public class Array {
	static Scanner sc= new Scanner(System.in);
	
	public static void main(String[] args){
		int a[]=new int[5];
		a[0]=1;
		int i=1;
		while(i<=4){
			a[i]=i+1;
			i++;
		}
		for(i=0;i<=4;i++)
		System.out.println(a[i]);

	}

}
