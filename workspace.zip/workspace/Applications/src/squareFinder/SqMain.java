package squareFinder;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Scanner;

public class SqMain extends JFrame {
	Container c;
	JTextField txt1;
	JButton btn1;
	JLabel lbl1, lbl2;
	
SqMain(){
	c= getContentPane();
	c.setLayout(new FlowLayout());
	lbl1=new JLabel("enter the Number");
	txt1=new JTextField(10);
	btn1=new JButton("ANSWER");
	lbl2=new JLabel();
	c.add(lbl1);
	c.add(txt1);
	c.add(btn1);
	c.add(lbl2);
	btn1.addActionListener(new MakeItWork());
}
	
	

	public static void main(String[] args) {
		SqMain frm= new SqMain();
		frm.setBounds(300,300,350,250);
		frm.setVisible(true);
		
		

	}
	class MakeItWork implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent ae) {
			int a = Integer.parseInt(txt1.getText());
			float s=a*a;
			lbl2.setText("Square="+s);
			
		}
		
	}

}
