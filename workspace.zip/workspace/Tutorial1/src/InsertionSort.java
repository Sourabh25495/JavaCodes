import java.util.Scanner;
public class InsertionSort {
	

		public static void main(String[] args) {
			int l;
			System.out.println("enter the length");
			Scanner in=new Scanner(System.in);
			l= in.nextInt();
		
			
			
			int[] a= new int[l];
			int i, temp;
			for(i=0;i<l;i++)
			{
				System.out.println("enter element"+(i+1));
				a[i]=in.nextInt();
			}
			in.close();
			int j;
			for(i=1;i<a.length;i++)
			{
				 int key=a[i];
				 j=i-1;
				while((j>-1)&&(a[j]>key))
				{
					a[j+1]=a[j];
					j =j-1;	
				}
				a[j+1]=key;
			}
			System.out.println("after sort");
			for(i=0;i<=a.length-1;i++)
				System.out.println(a[i]);
			
		}
}
