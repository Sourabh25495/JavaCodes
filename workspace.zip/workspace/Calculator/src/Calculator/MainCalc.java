package Calculator;

public class MainCalc {

	public static void main(String[] args) {
		Calculator c= new Calculator();
		
	}

}
