package session6;

import java.util.Scanner;

public class ArrayInvert {

	public static void main(String[] args) {
	
				int l;
				System.out.println("enter the length");
				Scanner in=new Scanner(System.in);
				l= in.nextInt();
				
				
				
				int[] a= new int[l];
				int i, temp;
				for(i=0;i<l;i++)
				{
					System.out.println("enter element"+(i+1));
					a[i]=in.nextInt();
				}
				in.close();
				
				for( i=0;i<a.length;i++){
					{
					    int temp1 = a[i];
					    a[i] = a[a.length - i - 1];
					    a[a.length - i - 1] = temp1;
					}
					for(i=0;i<a.length;i++)
					{
						System.out.println(a[i]);
					}
				}

	}

}
