import java .util.*;
public class RandomNumbers {
public static void main(String[] args){
	Random rnd= new Random();
	System.out.println(rnd.nextInt(100));
}
}
