/**
 * 
 * @author Sourabh
 * 
 */
package session6;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

//import java.awt.Color;
//import java.awt.Container;
import java.awt.*;

public class DrawWindow5 extends JFrame {


	public DrawWindow5(String title, Color bg){
		super(title);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800,400);
		Container c= getContentPane();
		c.setBackground(bg);
		JTextField t;;
		c.add(BorderLayout.NORTH, t= new JTextField(" "));
		t.setFont(new Font("times", Font.PLAIN, 28));

		
		JButton b = new JButton();
	//	c.add(BorderLayout.SOUTH, new JLabel("testing"));
		//JTextField t;
		//c.add(BorderLayout.SOUTH, t= new JTextField("testing"));
		//t.setFont(new Font("times", Font.PLAIN, 28));

		//c.add(BorderLayout.NORTH, b);
			
		JPanel p = new JPanel();
		p.setBackground(Color.GRAY);
		p.setLayout(new GridLayout(4,4, 5, 10));  // 2 rows 3 columns with 5 pixels in x and 10 pixels in y
		
		
		for(int i=1;i<=3;i++){
			 b= new JButton(i+"");
			p.add(b);
		}
		b= new JButton("+");
		p.add(b);
		for(int i=4;i<=6;i++){
			 b= new JButton(i+"");
			p.add(b);
		}
		b= new JButton("-");
		p.add(b);
		for(int i=7;i<=9;i++){
			 b= new JButton(i+"");
			p.add(b);
		}
		b= new JButton("x");
		p.add(b);
		b= new JButton(".");
		p.add(b);
		b= new JButton("0");
		p.add(b);
		b= new JButton("=");
		p.add(b);
		b= new JButton("/");
		p.add(b);
		
		c.add(BorderLayout.CENTER, p);
		
		p.setBackground(Color.GRAY);
		
		 
		 this.setVisible(true);	
	}
	
	
	
	
	
	public static void main(String[] args) {
	//new DrawWindow5("test", Color.RED);
	new DrawWindow5("hello", Color.BLUE);
	
	
	}

}
