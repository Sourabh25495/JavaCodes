
public class Tutorial1 {

	public static void main(String[] args) {
		String txt="\nHEllo\n!!!!!";
		System.out.println(txt);	}

}
