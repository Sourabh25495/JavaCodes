import java.util.*;
public class LinearSearch {

	public static void main(String[] args) {
		int l,key;
		System.out.println("enter the length");
		Scanner in=new Scanner(System.in);
		l= in.nextInt();
		
		
		
		int[] a= new int[l];
		int i, temp;
		for(i=0;i<l;i++)
		{
			System.out.println("enter element"+(i+1));
			a[i]=in.nextInt();
		}
		System.out.println("enter the key value to search");
		key=in.nextInt();
		int p;
		i=0;
		p=a[i];
		while(i<a.length){
			if(a[i]==key)
			{
				System.out.println("Number present at index" + i);
				break;
			}
			i++;
			
		}

	}

}
