package session6;

public class Car {
	private String color;
	int id;
	public Car(String c){ color=c;}
	public String toString(){ return "I am a Car. I am "+ color;}
	
	public String getColor(){return color;}
	public static void main(String[] args){
		Car c= new Car("red");
		System.out.println(c);
		SportsCar s= new SportsCar("blue", 320);
		System.out.println(s);
	}

}
