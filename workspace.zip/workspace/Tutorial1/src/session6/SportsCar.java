package session6;

public class SportsCar extends Car {// A sports car is a car or is a kind of car
    private int horsePower;
    
    
	public SportsCar(String color, int hp) {
	super(color);
	this.horsePower= hp;

	}
	public String toString(){ return "I am a SportCar. I am "+ this.getColor();}

}
