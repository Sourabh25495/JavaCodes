import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class GedComParser {	
	public static void main(String args[]) throws FileNotFoundException
	{
		Parse();
	}
	public static void Parse() throws FileNotFoundException  {
		Scanner input = new Scanner(System.in);
		System.out.println("The output is: ");
		File file = new File("C:/Users/soura/Desktop/inputfile.ged");
		input.close();
		 PrintWriter outputfile = new PrintWriter("C:/Users/soura/Desktop/myfile1.txt");
		
		
		
		input = new Scanner(file);
		while (input.hasNextLine()) {
            String line = input.nextLine();
            System.out.println("line:   " + line);
            outputfile.println("line:   " + line);
            
            
            String[] lineArr = line.split(" ");
            String level = lineArr[0];
            System.out.println("level:  " + level);
            outputfile.println("level:   " + level);
            
            String tagName = lineArr[1];
            if(level.equals("0") && tagName.startsWith("@")) {
            	tagName = lineArr[2];
            	
            }
    		
            System.out.println("tag:    " + tagName);
            outputfile.println("tag:   " + tagName);
            System.out.println();   
            outputfile.println();
           // outputfile.close();
          
        }
		outputfile.close();
				
		System.out.println("End of parsing");
		 
	}
		
	
}