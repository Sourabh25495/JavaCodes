import java.util.*;
public class HourGlassSum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int matrix[][]=new int[6][6];
		for(int i=0;i<6;i++)
			for(int j=0;j<6;j++)
				matrix[i][j]=sc.nextInt();
		
		
		for(int i=0;i<6;i++){
			for(int j=0;j<6;j++)
				System.out.print(matrix[i][j]+" ");
			System.out.println();
		}
		int maxHourGlassSum=0;
		
		 for (int i=0; i < (6-2); i++) {
	        	for (int j=0; j<(6-2); j++) {
	        		
	        		System.out.println ("Checking hourglass at (" + i + "," + j + ")");
	        		System.out.println(matrix[i][j] + " " + matrix[i][j+1] + " "  + matrix[i][j+2]);
	        		System.out.println("  " + matrix[i+1][j+1]);
	        		System.out.println(matrix[i+2][j] + " " + matrix[i+2][j+1] + " " + matrix[i+2][j+2]);
	        		
	        		int hourGlassSum = matrix[i][j]   + matrix[i][j+1]   + matrix[i][j+2] +
						    matrix[i+1][j+1] +
						    	matrix[i+2][j] + matrix[i+2][j+1] + matrix[i+2][j+2];
		
	        		System.out.println("hour glass sum = " + hourGlassSum);
	        		/* Is the new hourglass sum greater than the max found so far */
	        		if (hourGlassSum > maxHourGlassSum) {
	        			/* If so, then replace the max hour glass sum, with the current sum */
	        			maxHourGlassSum = hourGlassSum;
	        		}
	        	}
		 }
		 System.out.println("Maximum Hour Glass Sum = " + maxHourGlassSum);
		
		
		
		
		
		
		
		
		
		
		
	}

}
