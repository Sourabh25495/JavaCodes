package session6;
import javax.swing.JFrame;
public class DrawWindow {
	public static void main(String[] args) {
		JFrame f= new JFrame("test");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(800,400);
		f.setVisible(true);
		
		
		JFrame f1= new JFrame("test");
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f1.setSize(800,400);
		f1.setVisible(true);
		
		JFrame f2= new JFrame("test");
		f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f2.setSize(800,400);
		f2.setVisible(true);
	}

}
