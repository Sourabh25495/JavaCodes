import java.util.*;
public class CapStr {
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String a=" ";
		String b=" ";
		System.out.println("Enter String a");
		a=sc.nextLine();
		System.out.println("Enter String b");
		b=sc.nextLine();
		String first = a.substring(0,1);
	    String  a1 = a.replaceFirst(first, first.toUpperCase());
	    String second = b.substring(0,1);
		String  a2 = b.replaceFirst(second, second.toUpperCase());
		  //System.out.println(a1);
		char[] CharArray= a1.toCharArray();
		//System.out.println(CharArray.length);
		char[] CharArray1= a2.toCharArray();
		int v=CharArray1.length+CharArray.length;
		System.out.println(v);
		int i = 0;
		 if(a.charAt(i)>b.charAt(i))  
		 {
			 System.out.println("Yes");
			
		 }
		 else
		 {
			 System.out.println("No");
		 }
		 
		 for(i=0;i<CharArray.length;i++)
		 {
			 System.out.print(CharArray[i]);
		 }
		 System.out.print(" ");
		 for(i=0;i<CharArray1.length;i++)
		 {
			 System.out.print(CharArray1[i]);
		 }
	}

}
