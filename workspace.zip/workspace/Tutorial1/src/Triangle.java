import java.util.Scanner;
public class Triangle {

	
	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		
		double base, height;
		System.out.println("Enter the base");
		base=sc.nextDouble();
		System.out.println("Enter the height");
	    height=sc.nextDouble();
	    
	    double area=(base*height)/2;
	    System.out.println("area=" +area);
  
	}

}
