import java.util.*;
public class FactorialInt {

	
	public static void Fact(int x)
	{
	int z=1;
	if(x<=0)
	{
		System.out.println("Ans is 1");
	}	
	else{
		for(int i=1;i<=x;i++)
		{
		z*=i;
		} 
		System.out.println(z);
	}
	
	System.out.print("The array is "); 
	 int[]a = Integer.toString(z).chars().map(c -> c-='0').toArray(); 
	    for(int d : a)
	        System.out.print(d +" "); 
	    System.out.println();
	    
	    int temp;
		for(int i=0;i<a.length-1;i++){
			for(int j=0;j<a.length-1;j++){
				if(a[j]>a[j+1])
				{ 
					temp= a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		System.out.print("The Sorted array is ");
		for(int i=0;i<a.length;i++)
		{
			
			System.out.print(a[i]+" ");
		}
		int i=0, count=0;
		while(i<a.length)
		{
			
			 if(a[i]==0)
				 count++;
				i++;
		}
		System.out.println("\n"+"Total number of Zeros "+count);

		
	}
	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the number");
	int a= sc.nextInt();
	Fact(a);
	

	}

}
