
public class IntByte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=-2_147_483_648;
		int num2=2_147_483_647;
		
        byte b1=-128;
        short s1=32767;
        
	}

}
