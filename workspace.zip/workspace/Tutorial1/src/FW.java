import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class FW {
public static void main(String args[])
{
	File newFile = new File("C:/Users/soura/OneDrive/Documents/Java3.txt");
			if (newFile.exists())
				System.out.println("Already present");
			else
			{
				try
				{
				newFile.createNewFile();
			}
				catch(Exception e)
				{
					e.printStackTrace();
					}
				try{
				FileWriter fileW=new FileWriter(newFile);
				BufferedWriter buffw=new BufferedWriter(fileW);
				buffw.write("Hi there, my name is sourabh");
				buffw.close();
				System.out.println("Written");}
						catch(Exception e){e.printStackTrace();};
				}
			}
}
