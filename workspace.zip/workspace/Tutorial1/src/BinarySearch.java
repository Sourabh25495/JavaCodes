import java.util.*;
public class BinarySearch {
	public static void main(String[] args) {
		int l,key;
		System.out.println("enter the length");
		Scanner in=new Scanner(System.in);
		l= in.nextInt();
		
		
		
		int[] a= new int[l];
		int i, temp;
		for(i=0;i<l;i++)
		{
			System.out.println("enter element"+(i+1));
			a[i]=in.nextInt();
		}
		
		for(i=0;i<a.length-1;i++){
			for(int j=0;j<a.length-1;j++){
				if(a[j]>a[j+1])
				{
					temp= a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		
		System.out.println("Sorted array");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		System.out.println("enter the key value to search");
		key=in.nextInt();
		int index=search(a,key);
		if(index!=-1)
		    {
			System.out.println("element found at index "+ index);
			}

}
	public static int search(int[] arr, int k)
	{
		int first=0; 
		int last,mid;
		last=arr.length-1;
		while(first<last)
		{
			mid=(first+last)/2;
			if(arr[mid]==k)
			{
				return mid;
			}
			else 
			    {
				last= mid+1;
				}
		}
		return k;
	}
}
