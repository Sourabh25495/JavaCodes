
public class ObjectTst {

	public static void main(String[] args) {
		String x="hello";
		Objects waterBottle =new Objects();//Create new water bottle with no water
        waterBottle.addWater(100);//100 liters of water
        waterBottle.drinkWater(50);//Drink 20 liters of water
        System.out.println("remaining water "+ waterBottle.getWater());
	}

}
