import java.util.Scanner;
import javax.print.DocFlavor.STRING;
public class TutorialProject {
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args){
		inputTest();
		//countNumber();
		compare();
	}
public static void inputTest(){
	String message = input.nextLine();
	System.out.println(Hello(message));
	}
	public static String Hello(String message){
		if(message.equals("hi")){
			return "hello";
					
		}else{
			return "goodbye";
		}	
}
	public static void countNumber(){
		int i=0;
		while(i<=100){
			System.out.println(i);
			i++;
		}
	}
	public static void compare(){
		String x= "brendon";
		String y= "rut";
				if(!x.equals(y)){
					System.out.println("Noy equal");
					if(2!=5){
						System.out.println("2 not equal to 5");
					}
				}
	}
}
